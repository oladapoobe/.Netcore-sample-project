export interface ApplicationUser {
  username: string;
  role: string;
  originalUserName: string;
}
